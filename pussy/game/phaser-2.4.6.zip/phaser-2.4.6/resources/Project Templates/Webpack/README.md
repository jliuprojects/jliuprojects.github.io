# Phaser-Webpack

Simple boilerplate project that combines [Phaser](http://phaser.io) with [Webpack](http://webpack.github.io).

## Installation instructions

```
npm install webpack -g
```

## Build instructions

Run the following command to build the game

```
webpack src/entry.js build/bundle.js
```
