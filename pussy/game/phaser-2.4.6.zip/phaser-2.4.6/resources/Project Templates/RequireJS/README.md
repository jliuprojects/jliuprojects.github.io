
# Phaser-RequireJS

Boilerplate project that combines [Phaser](http://phaser.io) with [RequireJS](http://requirejs.org).

## Structure

The *Hello World* game is found in `www`. The `www` directory will need a `bower install`. Bower dependencies are configured to install into `www/src/libs`.

## NOTE

I haven't yet fully decided whether RequireJS is the right way of modularising a Phaser game.


## Change Log

### Version 0.1.0

 - Initial project.